from django.contrib import admin

# Register your models here.
# 注册common中的表
from django.contrib import admin
from .models import Customer
from .models import Medicine
from .models import Order


admin.site.register(Customer)
admin.site.register(Medicine)
admin.site.register(Order)
