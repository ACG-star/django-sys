from django.db import models
import datetime

# 数据库表的操作 通过 Model 类型的对象进行
# Customer类继承自 django.db.models.Model， 就是用来定义数据库表的


class Customer(models.Model):
    # 客户名称 varchar(200)
    name = models.CharField(max_length=200)
    # 联系电话
    phonenumber = models.CharField(max_length=200)
    # 地址
    address = models.CharField(max_length=200)


class Medicine(models.Model):
    # 药品名
    name = models.CharField(max_length=200)
    # 药品编号
    sn = models.CharField(max_length=200)
    # 描述
    desc = models.CharField(max_length=200)


class Order(models.Model):
    # 订单名
    name = models.CharField(max_length=200, null=True, blank=True)  # 可以为空或字段可传空白
    # blank = True、null = True。统一的表明了该字段（列）是可以为空的。
    # blank = False、null = False。统一的表面了该字段（列）不可以为空。
    # blank = True、null = False。这个设定的意义在于，某些字段并不希望用户在表单中创建（如slug），而是通过在save方法中根据其他字段生成。
    # blank = False、null = True。这个设定不允许表单中该字段为空，但是允许在更新时或者通过shell等非表单方式插入数据该字段为空。
    # 创建日期
    create_date = models.DateTimeField(default=datetime.datetime.now)  # 默认使用系统时间
    # 客户
    customer = models.ForeignKey(Customer, on_delete=models.PROTECT)  # on_delete=models.PROTECT删除时保护--禁止删除操作
    # 订单购买的药品，和Medicine表是多对多 的关系
    medicines = models.ManyToManyField(Medicine, through='OrderMedicine')  # ManyToManyField多对多关系

    # 为了提高效率，这里存放 订单 medicines 冗余数据
    medicinelist = models.CharField(max_length=2000, null=True, blank=True)


class OrderMedicine(models.Model):
    order = models.ForeignKey(Order, on_delete=models.PROTECT)
    medicine = models.ForeignKey(Medicine, on_delete=models.PROTECT)
    # 订单中药品的数量
    amount = models.PositiveIntegerField()
