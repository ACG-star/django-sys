"""
@File    :   testConnect.py
@Contact :   xwz3568@163.com

@Modify Time          @Author    @Version    @Description
------------          --------   --------    -----------
2023/4/10 0010 17:13  FuGui      1.0         接口测试
"""

import pprint
import requests

# # 构建添加 客户信息的 消息体，是json格式
# payload = {
#     "action": "add_customer",
#     "data": {
#         "name": "王二狗",
#         "phonenumber": "17864257358",
#         "address": "翻斗大街翻斗花园B1602"
#     }
# }
# # 发送请求给web服务
# response = requests.post('http://127.0.0.1:8000/api/mgr/customers', json=payload)
# pprint.pprint(response.json())
#
#
#
# # 列出所有信息
# response = requests.get('http://127.0.0.1:8000/api/mgr/customers?action=list_customer')
# pprint.pprint(response.json())


# 数据库管理员账号的登录
payload = {
    'username': 'pyFG',
    'password': '123456wz'
}
response = requests.post("http://127.0.0.1:8000/api/mgr/signin", data=payload)

retDict = response.json()

sessionid = response.cookies['sessionid']

# 再发送列出请求，注意多了 pagenum 和 pagesize
payload = {
    'action': 'list_medicine',
    'pagenum': 1,
    'pagesize': 3
}

response = requests.get('http://127.0.0.1:8000/api/mgr/medicines',
                        params=payload,
                        cookies={'sessionid': sessionid})

pprint.pprint(response.json())
