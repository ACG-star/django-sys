from django.urls import path

from mgr import customer
from mgr import sign_in_out
from mgr import medicine
from mgr import order

urlpatterns = [
    # 使用dispactchar分发函数
    path('customers', customer.dispatcher),  # http://127.0.0.1/mgr/customers.html
    path('medicines', medicine.dispatcher),
    path('orders', order.dispatcher),

    path('signin', sign_in_out.signin),  # http://127.0.0.1/mgr/signin.html
    path('signout', sign_in_out.signout),
]
