"""
@File    :   urls.py    
@Contact :   xwz3568@163.com

@Modify Time          @Author    @Version    @Description
------------          --------   --------    -----------
2023/3/15 0015 16:53  FuGui      1.0         sales接口的路由寻址
"""

from django.urls import path

from . import views

urlpatterns = [
    path('orders/', views.listorders),
]
