# coding=utf8
from django.shortcuts import render
from django.http import HttpResponse
# HttpRequest对象，包含了HTTP请求中的信息
# 导入 Customer 对象定义  无视pycharm报错
from common.models import Customer


def listorders(request):
    # 返回一个 QuerySet 对象 ，包含所有的表记录
    # 每条表记录都是是一个dict对象，
    # key 是字段名，value 是 字段值
    qs = Customer.objects.values()
    # 检查url中是否有参数phonenumber
    ph = request.GET.get('phonenumber', None)

    # 如果有，添加过滤条件
    if ph:
        qs = qs.filter(phonenumber=ph, address='翻斗大街翻斗花园A栋1102')
        # 添加filter即添加where字句，过滤条件多个时用逗号隔开，and关系

    # 定义返回字符串
    retStr = ''
    for customer in qs:  # 取一行
        for name, value in customer.items():  # 取每个属性
            retStr += f'{name} : {value} | '
        # <br> 表示换行
        retStr += '<br>'
    return HttpResponse(retStr)
